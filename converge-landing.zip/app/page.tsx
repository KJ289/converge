"use client"
import Link from "next/link"
import type React from "react"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  ArrowRight,
  Award,
  Building,
  CheckCircle,
  Globe,
  GraduationCap,
  Users,
  Instagram,
  Facebook,
  Twitter,
  Linkedin,
  Youtube,
  ChevronLeft,
  ChevronRight,
  ArrowDown,
  ExternalLink,
  Mail,
  Phone,
} from "lucide-react"
import { useState, useEffect, useRef } from "react"

export default function Home() {
  const router = useRouter()
  const [partnerDialogOpen, setPartnerDialogOpen] = useState(false)

  // Refs for scrolling to sections
  const aboutRef = useRef<HTMLDivElement>(null)
  const benefitsRef = useRef<HTMLDivElement>(null)
  const howItWorksRef = useRef<HTMLDivElement>(null)
  const testimonialsRef = useRef<HTMLDivElement>(null)
  const contactRef = useRef<HTMLDivElement>(null)

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    if (ref.current) {
      ref.current.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-2">
            <ConvergeLogo />
          </div>
          <nav className="hidden md:flex gap-6">
            <button
              onClick={() => scrollToSection(aboutRef)}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection(benefitsRef)}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Benefits
            </button>
            <button
              onClick={() => scrollToSection(howItWorksRef)}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              How It Works
            </button>
            <button
              onClick={() => scrollToSection(testimonialsRef)}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Testimonials
            </button>
            <button
              onClick={() => scrollToSection(contactRef)}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Contact
            </button>
          </nav>
          <Dialog open={partnerDialogOpen} onOpenChange={setPartnerDialogOpen}>
            <DialogTrigger asChild>
              <Button>Become a Partner</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Partner Application</DialogTitle>
                <DialogDescription>
                  Please provide your business details below to apply for partnership.
                </DialogDescription>
              </DialogHeader>
              <PartnerApplicationForm onSuccess={() => setPartnerDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-6 md:py-10 bg-gradient-to-b from-blue-50 to-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-4 lg:grid-cols-2 lg:gap-8 items-center">
              <div className="space-y-3">
                <h1 className="text-2xl font-bold tracking-tighter sm:text-3xl">
                  Partner with{" "}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-800 to-blue-400">
                    Converge
                  </span>
                </h1>
                <p className="max-w-[600px] text-gray-500 md:text-base/relaxed">
                  Join our global network of education partners and help students achieve their study abroad dreams
                  while growing your business.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button
                    size="default"
                    className="bg-gradient-to-r from-blue-800 to-blue-500 hover:from-blue-700 hover:to-blue-400"
                    onClick={() => router.push("/login")}
                  >
                    Login as Partner
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button size="default" variant="outline" onClick={() => scrollToSection(aboutRef)}>
                    Learn More
                    <ArrowDown className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="space-y-4">
                <div
                  id="about"
                  ref={aboutRef}
                  className="flex flex-col items-center justify-center space-y-3 text-center"
                >
                  <div className="w-full h-px bg-black/10 shadow-sm"></div>
                  <div className="space-y-1">
                    <h2 className="text-xl font-bold tracking-tighter sm:text-2xl">About Converge</h2>
                    <p className="max-w-[900px] text-gray-500 text-sm">
                      Converge is a premier study abroad partnership program connecting educational institutions,
                      consultants, and service providers worldwide. We help students find their ideal educational path
                      while providing partners with the tools and resources to grow their business.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 md:grid-cols-3 mt-4">
                  <Card className="border-blue-100 bg-blue-50/50 hover:shadow-md transition-all">
                    <CardHeader className="pb-1 pt-3">
                      <GraduationCap className="h-8 w-8 text-blue-600" />
                      <CardTitle className="mt-2 text-base">Educational Excellence</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-500 text-sm">
                        We partner with top-tier universities and colleges across the globe to provide quality education
                        options.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-blue-100 bg-blue-50/50 hover:shadow-md transition-all">
                    <CardHeader className="pb-1 pt-3">
                      <Globe className="h-8 w-8 text-blue-600" />
                      <CardTitle className="mt-2 text-base">Global Network</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-500 text-sm">
                        Join our extensive network spanning 50+ countries, connecting students with opportunities
                        worldwide.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-blue-100 bg-blue-50/50 hover:shadow-md transition-all">
                    <CardHeader className="pb-1 pt-3">
                      <Users className="h-8 w-8 text-blue-600" />
                      <CardTitle className="mt-2 text-base">Student Success</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-500 text-sm">
                        Our partners have helped over 10,000 students achieve their international education goals.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section
          id="benefits"
          ref={benefitsRef}
          className="w-full py-6 md:py-10 bg-gradient-to-b from-white to-blue-50"
        >
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-3 text-center">
              <div className="w-full h-px bg-black/10 shadow-sm"></div>
              <div className="space-y-1">
                <h2 className="text-xl font-bold tracking-tighter sm:text-2xl">Partner Benefits</h2>
                <p className="max-w-[900px] text-gray-500 text-sm">
                  Discover the advantages of becoming a Converge partner and how it can transform your business.
                </p>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mt-6">
              <div className="flex flex-col items-start gap-1 p-4 rounded-lg hover:bg-blue-50 transition-colors">
                <CheckCircle className="h-6 w-6 text-blue-600" />
                <h3 className="text-base font-bold">Increased Revenue</h3>
                <p className="text-gray-500 text-sm">
                  Earn competitive commissions on successful student placements and service referrals.
                </p>
              </div>
              <div className="flex flex-col items-start gap-1 p-4 rounded-lg hover:bg-blue-50 transition-colors">
                <CheckCircle className="h-6 w-6 text-blue-600" />
                <h3 className="text-base font-bold">Marketing Support</h3>
                <p className="text-gray-500 text-sm">
                  Access branded materials, digital assets, and marketing campaigns to promote your services.
                </p>
              </div>
              <div className="flex flex-col items-start gap-1 p-4 rounded-lg hover:bg-blue-50 transition-colors">
                <CheckCircle className="h-6 w-6 text-blue-600" />
                <h3 className="text-base font-bold">Training & Development</h3>
                <p className="text-gray-500 text-sm">
                  Receive comprehensive training on our processes, products, and international education trends.
                </p>
              </div>
              <div className="flex flex-col items-start gap-1 p-4 rounded-lg hover:bg-blue-50 transition-colors">
                <CheckCircle className="h-6 w-6 text-blue-600" />
                <h3 className="text-base font-bold">Dedicated Support</h3>
                <p className="text-gray-500 text-sm">
                  Work with a dedicated partnership manager to help grow your business and resolve issues.
                </p>
              </div>
              <div className="flex flex-col items-start gap-1 p-4 rounded-lg hover:bg-blue-50 transition-colors">
                <CheckCircle className="h-6 w-6 text-blue-600" />
                <h3 className="text-base font-bold">Exclusive Events</h3>
                <p className="text-gray-500 text-sm">
                  Participate in partner-only events, webinars, and networking opportunities with industry leaders.
                </p>
              </div>
              <div className="flex flex-col items-start gap-1 p-4 rounded-lg hover:bg-blue-50 transition-colors">
                <CheckCircle className="h-6 w-6 text-blue-600" />
                <h3 className="text-base font-bold">Technology Platform</h3>
                <p className="text-gray-500 text-sm">
                  Access our state-of-the-art partner portal to track applications, commissions, and student progress.
                </p>
              </div>
            </div>
            <div className="flex justify-center mt-8">
              <Button
                onClick={() => setPartnerDialogOpen(true)}
                className="bg-gradient-to-r from-blue-800 to-blue-500 hover:from-blue-700 hover:to-blue-400"
              >
                Apply for Partnership
              </Button>
            </div>
          </div>
        </section>

        <section id="how-it-works" ref={howItWorksRef} className="w-full py-6 md:py-10">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-3 text-center">
              <div className="w-full h-px bg-black/10 shadow-sm"></div>
              <div className="space-y-1">
                <h2 className="text-xl font-bold tracking-tighter sm:text-2xl">How It Works</h2>
                <p className="max-w-[900px] text-gray-500 text-sm">
                  A simple four-step process to become a Converge partner and start growing your business.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-2 gap-4 md:grid-cols-4 mt-6">
              <div className="flex flex-col items-center text-center p-4 rounded-lg hover:bg-blue-50/50 transition-colors">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-900">
                  <span className="text-lg font-bold">1</span>
                </div>
                <h3 className="mt-2 text-base font-bold">Apply</h3>
                <p className="mt-1 text-gray-500 text-sm">
                  Complete our partner application form with your business details.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-4 rounded-lg hover:bg-blue-50/50 transition-colors">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-900">
                  <span className="text-lg font-bold">2</span>
                </div>
                <h3 className="mt-2 text-base font-bold">Onboard</h3>
                <p className="mt-1 text-gray-500 text-sm">
                  After approval, complete our comprehensive onboarding program.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-4 rounded-lg hover:bg-blue-50/50 transition-colors">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-900">
                  <span className="text-lg font-bold">3</span>
                </div>
                <h3 className="mt-2 text-base font-bold">Collaborate</h3>
                <p className="mt-1 text-gray-500 text-sm">
                  Start referring students and utilizing our resources and support.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-4 rounded-lg hover:bg-blue-50/50 transition-colors">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-900">
                  <span className="text-lg font-bold">4</span>
                </div>
                <h3 className="mt-2 text-base font-bold">Grow</h3>
                <p className="mt-1 text-gray-500 text-sm">
                  Expand your business with increased referrals and partnership benefits.
                </p>
              </div>
            </div>
            <div className="mt-8 p-4 bg-blue-50/50 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">What to expect after applying</h3>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Application Review:</span> Our team will review your application
                    within 48 hours
                  </p>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Initial Call:</span> Schedule a call with our partnership team to
                    discuss your business needs
                  </p>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Agreement:</span> Review and sign our partnership agreement
                  </p>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Onboarding:</span> Complete our comprehensive onboarding program to
                    get started
                  </p>
                </li>
              </ul>
            </div>
          </div>
        </section>

        <section id="testimonials" ref={testimonialsRef} className="w-full py-6 md:py-10">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col space-y-3">
              <div className="w-full h-px bg-black/10 shadow-sm"></div>
              <div className="space-y-1">
                <h2 className="text-xl font-bold tracking-tighter sm:text-2xl">Partner Testimonials</h2>
                <p className="max-w-[900px] text-gray-500 text-sm">
                  Hear what our partners have to say about their experience with Converge.
                </p>
              </div>
            </div>
            <div className="mt-6 bg-blue-50/50 p-4 rounded-lg">
              <TestimonialSlider />
            </div>
            <div className="mt-6 grid md:grid-cols-2 gap-6">
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <h3 className="text-lg font-semibold mb-2">Partner Success Stories</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Our partners have achieved remarkable success through our collaboration. Here are some highlights:
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">40% increase</span> in student placements within the first year
                    </p>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">25% higher</span> conversion rates compared to industry average
                    </p>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Expanded services</span> to new regions and countries
                    </p>
                  </li>
                </ul>
              </div>
              <div className="bg-white p-4 rounded-lg border shadow-sm">
                <h3 className="text-lg font-semibold mb-2">Partner Recognition</h3>
                <p className="text-sm text-gray-600 mb-4">
                  We celebrate our partners' achievements through our annual recognition program:
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <Award className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Partner of the Year</span> awards in multiple categories
                    </p>
                  </li>
                  <li className="flex items-start gap-2">
                    <Award className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Excellence in Service</span> recognition for outstanding support
                    </p>
                  </li>
                  <li className="flex items-start gap-2">
                    <Award className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Innovation Awards</span> for partners implementing creative
                      solutions
                    </p>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section id="contact" ref={contactRef} className="w-full py-6 md:py-10">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col space-y-3">
              <div className="w-full h-px bg-black/10 shadow-sm"></div>
              <div className="space-y-1">
                <h2 className="text-xl font-bold tracking-tighter sm:text-2xl">Become a Partner</h2>
                <p className="max-w-[900px] text-gray-500 text-sm">
                  Ready to join our global network? Fill out the form and our partnership team will contact you within
                  48 hours.
                </p>
              </div>
            </div>
            <div className="mt-6 grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="space-y-2">
                  <p className="text-gray-500 text-sm">
                    Join our global network of education partners and help students achieve their study abroad dreams
                    while growing your business.
                  </p>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Award className="h-4 w-4 text-blue-600" />
                    <span className="text-gray-500 text-sm">Join 500+ partners worldwide</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="h-4 w-4 text-blue-600" />
                    <span className="text-gray-500 text-sm">Access to 1000+ universities</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="h-4 w-4 text-blue-600" />
                    <span className="text-gray-500 text-sm">Competitive commission structure</span>
                  </div>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-blue-800 to-blue-500 hover:from-blue-700 hover:to-blue-400">
                      Apply Now
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px] max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Partner Application</DialogTitle>
                      <DialogDescription>
                        Please provide your business details below to apply for partnership.
                      </DialogDescription>
                    </DialogHeader>
                    <PartnerApplicationForm />
                  </DialogContent>
                </Dialog>

                <div className="pt-4 border-t">
                  <h3 className="text-lg font-semibold mb-3">Contact Us Directly</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-blue-600" />
                      <a href="mailto:partners@converge.edu" className="text-sm text-blue-600 hover:underline">
                        partners@converge.edu
                      </a>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-blue-600" />
                      <a href="tel:+919876543210" className="text-sm text-blue-600 hover:underline">
                        +91 98765 43210
                      </a>
                    </div>
                    <div className="flex items-center gap-2">
                      <ExternalLink className="h-4 w-4 text-blue-600" />
                      <a href="#" className="text-sm text-blue-600 hover:underline">
                        Schedule a consultation call
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50/50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-4">Our Offices</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <h4 className="font-medium mb-2">Mumbai Office</h4>
                    <p className="text-sm text-gray-600 mb-2">
                      123 Business Park, Andheri East
                      <br />
                      Mumbai 400069, India
                    </p>
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Phone:</span> +91 22 1234 5678
                    </p>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <h4 className="font-medium mb-2">Hyderabad Office</h4>
                    <p className="text-sm text-gray-600 mb-2">
                      456 Tech Hub, Hitech City
                      <br />
                      Hyderabad 500081, India
                    </p>
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">Phone:</span> +91 40 8765 4321
                    </p>
                  </div>
                </div>
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Working Hours</h4>
                  <p className="text-sm text-gray-600">
                    Monday to Friday: 9:00 AM - 6:00 PM IST
                    <br />
                    Saturday: 10:00 AM - 2:00 PM IST
                    <br />
                    Sunday: Closed
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-gray-50 py-4">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ConvergeLogo />
            </div>

            <div className="flex items-center gap-4">
              <Link href="#" className="text-gray-500 hover:text-blue-600">
                <Instagram className="h-4 w-4" />
              </Link>
              <Link href="#" className="text-gray-500 hover:text-blue-600">
                <Facebook className="h-4 w-4" />
              </Link>
              <Link href="#" className="text-gray-500 hover:text-blue-600">
                <Twitter className="h-4 w-4" />
              </Link>
              <Link href="#" className="text-gray-500 hover:text-blue-600">
                <Linkedin className="h-4 w-4" />
              </Link>
              <Link href="#" className="text-gray-500 hover:text-blue-600">
                <Youtube className="h-4 w-4" />
              </Link>
            </div>

            <div className="flex flex-wrap justify-center md:justify-end gap-x-6">
              <div className="text-xs text-gray-500">
                <strong>Mumbai Office:</strong> 123 Business Park, Andheri East, Mumbai 400069
              </div>
              <div className="text-xs text-gray-500">
                <strong>Hyderabad Office:</strong> 456 Tech Hub, Hitech City, Hyderabad 500081
              </div>
            </div>
          </div>

          <div className="mt-3 flex flex-col md:flex-row items-center justify-between gap-2">
            <p className="text-center text-xs text-gray-500 md:text-left">
              © {new Date().getFullYear()} Converge. All rights reserved.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-xs text-gray-500 hover:text-gray-900">
                Privacy Policy
              </Link>
              <Link href="#" className="text-xs text-gray-500 hover:text-gray-900">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

function ConvergeLogo() {
  return (
    <div className="font-bold text-lg">
      <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-800 to-blue-400">CONVERGE</span>
    </div>
  )
}

function PartnerApplicationForm({ onSuccess }: { onSuccess?: () => void }) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      if (onSuccess) onSuccess()
      // In a real app, you would handle form submission here
    }, 1500)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3 py-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <label
            htmlFor="first-name"
            className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            First Name
          </label>
          <Input id="first-name" placeholder="John" className="h-8 text-sm" required />
        </div>
        <div className="space-y-1">
          <label
            htmlFor="last-name"
            className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Last Name
          </label>
          <Input id="last-name" placeholder="Doe" className="h-8 text-sm" required />
        </div>
      </div>
      <div className="space-y-1">
        <label
          htmlFor="company"
          className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
        >
          Company Name
        </label>
        <Input id="company" placeholder="Your Education Agency" className="h-8 text-sm" required />
      </div>
      <div className="space-y-1">
        <label
          htmlFor="email"
          className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
        >
          Email
        </label>
        <Input id="email" placeholder="john@example.com" type="email" className="h-8 text-sm" required />
      </div>
      <div className="space-y-1">
        <label
          htmlFor="phone"
          className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
        >
          Phone
        </label>
        <Input id="phone" placeholder="+1 (555) 000-0000" type="tel" className="h-8 text-sm" required />
      </div>
      <div className="space-y-1">
        <label
          htmlFor="country"
          className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
        >
          Country
        </label>
        <Input id="country" placeholder="United States" className="h-8 text-sm" required />
      </div>
      <div className="space-y-1">
        <label
          htmlFor="message"
          className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
        >
          Tell us about your business
        </label>
        <Textarea
          id="message"
          placeholder="Brief description of your business and services"
          className="text-sm h-16 min-h-0 resize-none"
          required
        />
      </div>
      <Button
        type="submit"
        className="w-full bg-gradient-to-r from-blue-800 to-blue-500 hover:from-blue-700 hover:to-blue-400 h-8 text-sm"
        disabled={isSubmitting}
      >
        {isSubmitting ? "Submitting..." : "Submit Application"}
      </Button>
    </form>
  )
}

function TestimonialSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const sliderRef = useRef<HTMLDivElement>(null)

  const testimonials = [
    {
      name: "Global Education Consultants",
      location: "Mumbai, India",
      text: "Partnering with Converge has transformed our business. The support and resources provided have helped us increase our student placements by 40% in just one year.",
    },
    {
      name: "Future Pathways",
      location: "Sydney, Australia",
      text: "The Converge partnership program offers unmatched support and training. Their team is always available to help with any questions or challenges we face.",
    },
    {
      name: "EduConnect",
      location: "Lagos, Nigeria",
      text: "Since joining Converge, we've been able to offer our students a wider range of options and services. The commission structure is transparent and rewarding.",
    },
    {
      name: "Study Abroad Experts",
      location: "Toronto, Canada",
      text: "Working with Converge has been a game-changer for our consultancy. Their technology platform makes tracking applications and commissions effortless.",
    },
    {
      name: "Global Scholars",
      location: "Singapore",
      text: "The marketing support and training provided by Converge has helped us reach more students and improve our conversion rates significantly.",
    },
  ]

  const nextSlide = () => {
    if (sliderRef.current) {
      const itemsPerPage = window.innerWidth < 768 ? 1 : window.innerWidth < 1024 ? 2 : 3
      setCurrentIndex((prev) => (prev + 1) % (testimonials.length - itemsPerPage + 1))
    }
  }

  const prevSlide = () => {
    if (sliderRef.current) {
      const itemsPerPage = window.innerWidth < 768 ? 1 : window.innerWidth < 1024 ? 2 : 3
      setCurrentIndex(
        (prev) => (prev - 1 + (testimonials.length - itemsPerPage + 1)) % (testimonials.length - itemsPerPage + 1),
      )
    }
  }

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 4000)

    return () => clearInterval(interval)
  }, [currentIndex])

  return (
    <div className="relative">
      <div className="absolute left-0 top-1/2 -translate-y-1/2 z-10">
        <button
          onClick={prevSlide}
          className="p-1 rounded-full bg-white shadow-md hover:bg-gray-100"
          aria-label="Previous testimonial"
        >
          <ChevronLeft className="h-4 w-4 text-blue-600" />
        </button>
      </div>

      <div ref={sliderRef} className="overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * 33.333}%)` }}
        >
          {testimonials.map((testimonial, index) => (
            <div key={index} className="min-w-[100%] md:min-w-[50%] lg:min-w-[33.333%] p-2">
              <Card className="h-full shadow-sm">
                <CardHeader className="pb-2 pt-3">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <Building className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{testimonial.name}</CardTitle>
                      <CardDescription className="text-xs">{testimonial.location}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-gray-500 text-sm">"{testimonial.text}"</p>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute right-0 top-1/2 -translate-y-1/2 z-10">
        <button
          onClick={nextSlide}
          className="p-1 rounded-full bg-white shadow-md hover:bg-gray-100"
          aria-label="Next testimonial"
        >
          <ChevronRight className="h-4 w-4 text-blue-600" />
        </button>
      </div>
    </div>
  )
}
